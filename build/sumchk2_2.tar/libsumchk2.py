#!/usr/bin/env python 2.5

import sys


CANONICAL_PARAMETERS = [
    # IMPORTANT: IDENTIFIERS ONLY
    # SEE NUM_IDENTIFIERS, BELOW FOR IMPORTANT INFORMATION
    "SHIP/CRS EXPOCODE",
    "WOCE SECT",
    "STNNBR",
    "CASTNO",
    "CAST TYPE",
    "EVENT CODE",
    # IMPORTANT: DO NOT INSERT PARAMETERS BEFORE THIS LINE
    "DATE",
    "UTC TIME",
    "LATITUDE",
    "LONGITUDE",
    "NAV",
    "UNC DEPTH",
    "COR DEPTH",
    "HT ABOVE BOTTOM",
    "WIRE OUT",
    "MAX PRESS",
    "NO. OF BOTTLES",
    "PARAMETERS",
    # Insert extra parameters here
    "COMMENTS", ]

# Beware this line. If new identifiers are added, MAKE SURE you change
# the slice number accordingly.
NUM_IDENTIFIERS = 6
CANONICAL_IDENTIFIERS = CANONICAL_PARAMETERS[:NUM_IDENTIFIERS]

KNOWN_EVENT_CODES = ['BE', 'BO', 'EN', 'AT', 'DE', 'MR', 'RE', 'UN', ]


GLOBAL_EXPOCODE = None
MAXIMUM_ERRORS = 20

VERBOSE = True
ROBUST = False
EXPEDIENT = False


def log(msg):
    """Log a diagnostic message, if allowed."""
    global VERBOSE
    if VERBOSE:
        print >> sys.stderr, msg


def load_param(line, begin, end, ):
    """Load a parameter from a line based on given bounds.

    Validate character index boundaries in the line, then extract and
    package the result. If blank, returns None.
    """
    if begin >= end or begin == -1 or end == -1:
        return None

    c = ""
    try:
        c = line[begin:end].strip()
    except IndexError:
        pass

    if len(c) == 0:
        return None
    else:
        return c


def next_param(bounds, canonical_parameter, ):
    """Determine next parameter in line.

    Consults boundary dictionary to find the parameter that
    seqeuentially follows the given parameter on a line in
    the current file.
    """
    global CANONICAL_PARAMETERS
    if canonical_parameter not in bounds:
        log("libsumchk2.next_param: illegal attempt to get parameter after %s" % canonical_parameter)
        return None
    next = CANONICAL_PARAMETERS[-1]
    for parameter in CANONICAL_PARAMETERS:
        if (parameter in bounds and
                bounds[parameter] > bounds[canonical_parameter] and
                bounds[parameter] < bounds[next]):
            next = parameter
    return next if next != canonical_parameter else None


def initialize():
    """Prepare library for file check.

    Reset GLOBAL_EXPOCODE to None.
    """
    global GLOBAL_EXPOCODE
    GLOBAL_EXPOCODE = None

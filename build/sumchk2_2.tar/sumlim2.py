#!/usr/bin/env python2.5
""" sumlim2

Column boundary parser and header verification for WOCE summary files.
"""

import re
import sys

import libsumchk2


WARNING = 1             # general warning.
AMBIGUOUS = 2           # parameter /BO(?:TT?)?/ could be BOTTOM or BOTTLES
CLOBBERED = 4           # tried to repair a conjoined parameter.
IRREPARABLE_CONJOIN = 8 # could not repair a conjoined parameter.
STRANGE_PARAMETER = 16  # unrecognized parameter.


def notspace(x):
    """Whether a character exists and is not a space."""
    return x and x != ' '


def chr_union(x, y):
    """Yield a flag if either character is not a space."""
    return '!' if notspace(x) or notspace(y) else ' '


def str_union(a, b):
    """Yield flag string for spacewise union of two strings."""
    return ''.join(map(chr_union, a, b))


def header_join(a, b):
    """Join two given headers."""
    return (a.strip() + ' ' + b.strip()).strip()


def header_cat(a, b, i, j):
    """Join headers at given position in given header lines."""
    return header_join(a[i:j], b[i:j])


def vfinds(regex, list):
    """Find matches for a regex in a list of strings."""
    return [re.search(regex, s) for s in list]


def verify_headers(bounds, header1, header2, ):
    """ Verify parameter headers for usability.

    Check parameters in required and aliasable groups for whether they can
    be recognized as a parameter. If a fallback is used, a deprecation or
    reformat warning should be issued; if any required parameter is missing
    an errlv is raised to the caller. Fallbacks are replaced with their
    canonical representations.

    Parameters:
        bounds: character column boundaries hash from get_summary_limits()
                to be verified for header integrity in this function; i.e.,
                to make sure the headers formed by splitting across these
                boundaries are valid and recognizable.
        header1: first header line; should contain "POSITION" for legacy
                reasons
        header2: second header line; contains most important parts of most
                parameters

    Returns ( [ beginning_character_column_indices ], errlv )
    """

    # required parameters
    # if they are not found, resort to using regular expressions to try to
    # guess whether the parameter is included but badly named. if fallbacks
    # are matched, a warning should be given; when neither is found, an
    # error occurs.
    params_and_fallbacks = {
            "SHIP/CRS EXPOCODE": "EXPO",
            "WOCE SECT": "(SECT(_ID)?|WHP_ID)",
            "STNNBR": "STN(N(BR?)?)?",
            "CASTNO": "CAS(T(NO?)?)?",
            "CAST TYPE": "C?TYPE",
            "DATE": "DATE",
            "UTC TIME": "TIME",
            "EVENT CODE": "(\\b|T)CODE",
            "LATITUDE": "LAT",
            "LONGITUDE": "LONG?",
            "NAV": "NAV",
            "NO. OF BOTTLES": "BOTTL(ES?)?", # FIXME
            "PARAMETERS": "PAR(AM?)?",
            "COMMENTS": "CO(\\b|M(M(E(N(TS?)?)?)?)?)",
    # aliasable parameters
    # parameters that can also exist with alias(es). if they are not found,
    # any header that matches the regular expression is equally acceptable.
            "MAX PRESS": "PRESS(_MX)?",
            "WIRE OUT": "WHEEL(_MT)?",
            "HT ABOVE BOTTOM": "(BOT(TOM(HT)?)?|HAB)",
            "UNC DEPTH": "\\bDEP(TH)?",
            "COR DEPTH": "CDEP(TH)?",
    }

    # error messages for parameter format problems
    EFIXME = "please correct immediately."
    # strange: not canonical and does not match any rules for guessing
    #   which parameter it should be
    STRANGE = "sumlim2: strange parameter '%%s'; %s" % EFIXME
    # deprecated: not canonical, but recognizable
    DEPRECATED = "sumlim2: deprecated parameter '%s'; please use '%s'"
    # conjoined: missing a space delimiter between columns. looks like
    #   two parameters at once; should be corrected here with a warning.
    CONJOINED = "sumlim2: conjoined parameter '%s'; attempting repair..."

    UNABLE_TO_REPAIR = ("sumlim2: unable to repair conjoined " +
                        "parameters; %s" % EFIXME)

    # ambiguous "bot": a parameter has the form /BO(?:TT?)?/ and can't
    #   be resolved to either NO. OF BOTTLES or HT ABOVE BOTTOM.
    AMBIGUOUS_BOT = "sumlim2: ambiguous parameter '%s'"

    # errorlevel
    errlv = 0

    # get the headers for each column
    column_headers = []
    for i in range(len(bounds) - 1):
        column_headers.append(header_cat(header1, header2,
                                         bounds[i], bounds[i + 1]))
    # don't forget the last column!
    column_headers.append(
            header_join(header1[bounds[-1]:], header2[bounds[-1]:]))

    # check each retrieved column header for errors
    i = 0
    while i < len(column_headers):
        header = column_headers[i]

        # non-canonical parameter check
        if header not in params_and_fallbacks:
            # count up fallback matches
            matches = 0
            matched_headers = []
            for param in params_and_fallbacks:
                fallback = params_and_fallbacks[param]
                search_result = re.search(fallback, header)
                if search_result is not None:
                    matches += 1
                    matched_headers.append(param)

            # determine header integrity
            if matches == 0:
                libsumchk2.log(STRANGE % header)
                errlv |= STRANGE_PARAMETER

            elif matches == 1:
                # handle ambiguous "BOT" parameter, if any
                if header in ('BOT', 'BOTT'):
                    libsumchk2.log(AMBIGUOUS_BOT % header)
                    errlv |= AMBIGUOUS
                else:
                    libsumchk2.log(DEPRECATED % (header,
                                     matched_headers[0]))
                    column_headers[i] = matched_headers[0]
                errlv |= WARNING

            else:
                libsumchk2.log(CONJOINED % header)
                ##print matched_headers
                errlv |= WARNING
                # try to fix conjoined header in bounds array
                # NB. can't and won't fix merged headers e.g.
                #     HT ABOVE MAX
                #     BOTTOM PRESS
                top = header[:len(header) / 2]
                bottom = header[len(header) / 2 + 1:]

                def ok_p(h):
                    return h in params_and_fallbacks

                done = False
                for j in range(1, len(top)):
                    # try to separate headers at char-col j
                    left = (top[:j].strip() + ' ' +
                            bottom[:j].strip()).strip()
                    right = (top[j:].strip() + ' ' +
                             bottom[j:].strip()).strip()

                    # operation succeeded
                    if ok_p(left) and ok_p(right):
                        if not libsumchk2.EXPEDIENT:
                            # confirm change unless expedient execution
                            print "assuming '%s' and '%s';" % (left, right),
                            print "is this OK? (y/N)",
                            if raw_input() not in ['y', 'Y']:
                                break
                        errlv |= CLOBBERED
                        bounds[i + 1:i + 1] = [bounds[i] + j]
                        column_headers[i:i + 1] = [left, right]
                        done = True
                        break

                # operation failed
                if not done:
                    libsumchk2.log(UNABLE_TO_REPAIR)
                    errlv |= IRREPARABLE_CONJOIN
        i += 1

    return (column_headers, errlv)


def get_summary_limits(header_1, header_2, ):
    """ Determine char-column beginning indices for summary parameters.

    Use 'smart' column generation to parse the given headers for the
    boundaries of the parameter columns. Verify that the parameter headers
    are acceptable, and yield a mapping of the parameter names to their
    beginning indices.

    Parameters:
        header_1: first header line.
        header_2: second header line.

    Returns { parameter_header: beginning_character_column_index }
    """
    header1 = header_1.rstrip()
    header2 = header_2.rstrip()

    # make sure headers are of same length to avoid index errors
    if len(header2) < len(header1):
        header2 += ' ' * (len(header1) - len(header2))
    elif len(header1) < len(header2):
        header1 += ' ' * (len(header2) - len(header1))

    # upper header line should have /(?i)POSITION/ to be considered valid.
    # if it doesn't appear, try to keep parsing anyway.
    if re.search("(?i)POSITION", header1) is not None:
        place = re.search("(?i)POSITION", header1).span()
        header1 = header1.replace(header1[place[0]:place[1]], '        ')
    else:
        libsumchk2.log("sumlim2: can't recognize header, "+
                "but will try to continue.")

    lims = str_union(header1, header2)

    # get character index boundaries for colums
    bounds = [0] # include beginning of line
    for c in range(len(lims)):
        if (lims[c] == ' ' and c + 1 < len(lims) and lims[c + 1] != ' '):
            bounds.append(c + 1)

    # verify header integrity (see above)
    headers, warnlv = verify_headers(bounds, header1, header2)
    if warnlv > 0:
        errstr = "sumlim2: errlv %d ( " % warnlv
        if warnlv & WARNING:
            errstr += "WARNING ",
        if warnlv & AMBIGUOUS:
            errstr += "AMBIGUOUS ",
        if warnlv & CLOBBERED:
            errstr += "CLOBBERED ",
        if warnlv & IRREPARABLE_CONJOIN:
            errstr += "IRREPARABLE_CONJOIN ",
        if warnlv & STRANGE_PARAMETER:
            errstr += "STRANGE_PARAMETER ",
        errstr += ")"
        libsumchk2.log(errstr)

    # yield parameter name mapped to beginning index
    return dict(zip(headers, bounds))


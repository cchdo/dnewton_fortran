#!/usr/bin/env python2.5

import libsumchk2


def get_summary_identifiers(line, bounds, ):
    """Read identifiers from a line.

    Leverage the library's global parameter loading function to try to
    load identifying parameters from a line. Special parsing is required
    for EXPOCODE and CASTNO to make sure that
     - EXPOCODEs are the same across the file (legacy requirement)
     - CASTNOs are numeric

    Parameters
        line: current line; contains identifiers to be extracted.
        bounds: character column boundaries hash from get_summary_limits()
                used for referencing identifier boundaries.

    Returns ( { identifier: value }, errlv )
    """
    OK = 0
    ILLEGAL_EXPOCODE = 1

    the_identifiers = {}

    # Iterate across all canonical identifiers
    for identifier in libsumchk2.CANONICAL_IDENTIFIERS:
        # get identifier value
        value = libsumchk2.load_param(line, bounds[identifier],
                bounds[libsumchk2.next_param(bounds, identifier)])

        # make sure EXPOCODE is uniform across file (legacy requirement)
        if identifier == "SHIP/CRS EXPOCODE":
            if value and not libsumchk2.GLOBAL_EXPOCODE:
                libsumchk2.GLOBAL_EXPOCODE = value
            elif value != libsumchk2.GLOBAL_EXPOCODE:
                return (the_identifiers, ILLEGAL_EXPOCODE)

        # make sure CASTNO is numeric
        elif identifier == "CASTNO":
            try:
                value = int(value)
            except (TypeError, ValueError):
                value = -9
       
        # store identifer-value pair
        the_identifiers[identifier] = value

    return (the_identifiers, OK)


def get_summary_data(line, bounds, ):
    """Read and parse data from an entry.

    Leverage the library's global parameter loading function to load
    and parse a full line. Individual parameters are classified by
    the parsing callback needed to sanitize them and their errors are
    collected into a summary error.

    Parameters:
        line: current line; contains data to be parsed.
        bounds: character column boundaries hash from get_summary_limits()
                for referencing parameter boundaries.

    Returns ( { parameter: value }, errlv )
    """

    OK = 0
    LIBRARY_ERROR = 1  # error in libsumchk2.load_param(); entry is None
    PARSE_ERROR = 2    # TypeError or ValueError in int() or float()
    INTERNAL_ERROR = 8 # value not in acceptable range

    if len(line) < max(bounds.values()):
        line = line + (' ' * (max(bounds.values()) - len(line)))

    def sumun_expocode(entry):
        """Parse expocodes."""
        LEN_SHIP_ID = 4
        if not entry:
            return ((None, None), LIBRARY_ERROR)
        elif len(entry) < LEN_SHIP_ID:
            return ((entry, entry), OK)
        return ((entry[:LEN_SHIP_ID], entry), OK)

    def sumun_str(entry):
        """Parse string values (do nothing)."""
        return (entry, OK)

    def sumun_eventcode(entry):
        """Validate event codes."""
        if not entry or entry not in libsumchk2.KNOWN_EVENT_CODES:
            return None
        return (entry, OK)

    def sumun_num(entry):
        """Parse numerical parameters."""
        if not entry:
            return (-9, LIBRARY_ERROR)
        try:
            return (int(entry), OK)
        except (TypeError, ValueError):
            return (-9, PARSE_ERROR)

    def sumun_date(entry):
        """Parse the DATE parameter."""
        if not entry:
            return ((-9, -9, -9), LIBRARY_ERROR)
        if entry.find(' ') != -1:
            entry.translate(None, ' ')
        elif len(entry) != 6: # 5-char date
            entry = ('0'*(6 - len(entry))) + entry
        try:
            return ((int(entry[:2]), int(entry[2:4]), int(entry[4:])), OK)
        except (TypeError, ValueError):
            return ((-9, -9, -9), PARSE_ERROR)

    def sumun_time(entry):
        """Parse the TIME parameter."""
        h = -9
        m = -9
        if not entry:
            return ((h, m), LIBRARY_ERROR)
        if entry.find(' ') != -1:
            entry.translate(None, ' ')
        elif len(entry) != 4: # 3-char time
            entry = '0' + entry
        try:
            h = int(entry[:2])
            m = int(entry[2:])
        except (TypeError, ValueError):
            h = -9
            m = -9
        if h not in range(24) or m not in range(60):
            return ((-9, -9), INTERNAL_ERROR)
        return ((h, m), OK)

    def sumun_pos(entry):
        """Parse LATITUDE and LONGITUDE."""
        _ans_on_err = (0, 0, '')
        degs = 0
        mins = 0
        hemi = ''
        if not entry:
            return (_ans_on_err, LIBRARY_ERROR)
        try:
            degs, mins, hemi = entry.split(None)
            degs = float(degs)
            mins = float(mins)
        except (TypeError, ValueError):
            return (_ans_on_err, PARSE_ERROR)
        if hemi not in ('N', 'S', 'E', 'W'):
            return (_ans_on_err, INTERNAL_ERROR)
        if degs < 0.0 or degs > 180.0 or mins < 0.0 or mins > 60.0:
            return (_ans_on_err, INTERNAL_ERROR)
        return ((degs, mins, hemi), OK)

    # XXX WARNING: You MUST update this dictionary if you change the
    # canonical parameters in libsumchk2 to contain the correct parsing
    # callbacks for each parameter!
    parse_callbacks = dict(zip(libsumchk2.CANONICAL_PARAMETERS, [
        sumun_expocode, sumun_str, sumun_str,
        sumun_num, sumun_str, sumun_eventcode,
        sumun_date, sumun_time,
        sumun_pos, sumun_pos,
        sumun_str,
        sumun_num, sumun_num,
        sumun_num, sumun_num,
        sumun_num,
        sumun_num,
        sumun_str, sumun_str, ]))

    all_items = {}
    errlv = 0

    for parameter in libsumchk2.CANONICAL_PARAMETERS[
            libsumchk2.NUM_IDENTIFIERS:]:
        if parameter not in bounds: # skip parameters not in file
            continue
        next_param = libsumchk2.next_param(bounds, parameter)
        if not next_param: # COMMENTS
            next_bound = len(line)
        else:
            next_bound = bounds[next_param]

        # extract and parse parameter value
        value = libsumchk2.load_param(line, bounds[parameter], next_bound)
        all_items[parameter], current_err = parse_callbacks[parameter](value)

        # diagnostics: explain errlevels
        ##if current_err & LIBRARY_ERROR:
        ##    libsumchk2.log("sumqwk2: error loading %s" % parameter)
        if current_err & PARSE_ERROR:
            libsumchk2.log("sumqwk2: error parsing %s to numeric" % parameter)
        if current_err & INTERNAL_ERROR:
            libsumchk2.log("sumqwk2: invalid value for %s" % parameter)
        errlv |= (current_err & ~LIBRARY_ERROR)

    return (all_items, errlv)

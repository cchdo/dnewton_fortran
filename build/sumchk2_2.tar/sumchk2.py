#!/usr/bin/env python2.5

from __future__ import with_statement

import sys
import optparse

import libsumchk2
import sumlim2
import sumqwk2


def sumchk(filename, ):
    """Check a WOCE summary file.

    Extract column limits for the parameters in a summary file and try to
    validate the syntax of its data entries.

    Parameters:
        filename: name of WOCE summary file to validate.
    """
    libsumchk2.initialize()

    with open(filename, 'rb') as file:
        file.readline() # bottle header
        bounds = sumlim2.get_summary_limits(file.readline(), file.readline())
        file.readline() # table divider

        num_checked_lines = 0
        num_errors = 0

        for line in file:
            # grab and validate identifying parameters
            identifiers, errlv = sumqwk2.get_summary_identifiers(line, bounds)
            if errlv != 0:
                num_errors += 1
                if (not libsumchk2.ROBUST and
                        num_errors > libsumchk2.MAXIMUM_ERRORS):
                    break
                else:
                    continue

            # validate data parameters
            num_checked_lines += 1
            data, errlv = sumqwk2.get_summary_data(line, bounds)
            if errlv != 0:
                num_errors += 1
                if (not libsumchk2.ROBUST and
                        num_errors > libsumchk2.MAXIMUM_ERRORS):
                    break

        # diagnostic summary
        libsumchk2.log("%s: %3d errors" % (filename, num_errors))


def main():
    parser = optparse.OptionParser(usage="usage: %prog [options] FILE ...",
            version="%prog 0.2-beta")
    parser.add_option("-v", "--verbose",
            action="store_true",
            dest="verbose",
            default=True,
            help="show diagnostic messages (default)")
    parser.add_option("-q", "--quiet",
            action="store_false",
            dest="verbose",
            help="hide diagnostic messages")
    parser.add_option("-r", "--robust", "--dont-die",
            action="store_true",
            dest="robust",
            default=False,
            help="continue parsing regardless of errors")
    parser.add_option("-e", "--max-error",
            metavar="N",
            dest="MAX_ERR",
            default=None,
            help="allow N errors before aborting (superseded by --robust)")
    parser.add_option("-f", "--force", "--fix",
            action="store_true",
            dest="expedient",
            default=False,
            help="run without prompting for fixes (for conjoined parameters)")

    options, args = parser.parse_args()
    libsumchk2.MAXIMUM_ERRORS = options.MAX_ERR if options.MAX_ERR else 20
    libsumchk2.VERBOSE = options.verbose
    libsumchk2.ROBUST = options.robust
    libsumchk2.EXPEDIENT = options.expedient

    for filename in args:
        sumchk(filename)


if __name__ == '__main__':
    main()
